import { Check, Zap } from "lucide-react";

const plans = [
  {
    name: "Starter",
    price: "Free",
    period: "forever",
    desc: "Get moving with the essentials.",
    features: ["5 workout plans", "Basic calorie tracking", "Progress graphs", "Community access"],
    cta: "Start Free",
    highlight: false,
  },
  {
    name: "Pro",
    price: "$14",
    period: "/month",
    desc: "The full Pulse experience.",
    features: [
      "Unlimited workout plans",
      "AI meal scanner",
      "Advanced analytics",
      "Personalized coaching",
      "Wearable integrations",
      "Offline mode",
    ],
    cta: "Go Pro",
    highlight: true,
  },
  {
    name: "Elite",
    price: "$39",
    period: "/month",
    desc: "1-on-1 with a human coach.",
    features: [
      "Everything in Pro",
      "Weekly video coaching calls",
      "Custom meal plans",
      "Form-check video review",
      "Priority 24/7 support",
    ],
    cta: "Train Elite",
    highlight: false,
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="py-24 md:py-32 relative">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-widest mb-4">
            Pricing
          </div>
          <h2 className="text-4xl md:text-6xl font-display font-black mb-5">
            Pick your <span className="text-gradient-primary">level</span>.
          </h2>
          <p className="text-lg text-muted-foreground">
            Start free. Upgrade when you're ready to go all-in. Cancel anytime.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {plans.map((p) => (
            <div
              key={p.name}
              className={`relative rounded-3xl p-8 transition-all hover:-translate-y-2 duration-300 ${
                p.highlight
                  ? "bg-gradient-primary text-primary-foreground shadow-glow scale-105 border-2 border-primary"
                  : "bg-surface/60 border border-border hover:border-primary/50"
              }`}
            >
              {p.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-foreground text-background px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-1">
                  <Zap className="size-3 fill-current" /> Most Popular
                </div>
              )}
              <h3 className="font-display font-bold text-2xl mb-1">{p.name}</h3>
              <p className={`text-sm mb-6 ${p.highlight ? "opacity-80" : "text-muted-foreground"}`}>
                {p.desc}
              </p>
              <div className="flex items-baseline gap-1 mb-8">
                <span className="text-5xl font-display font-black">{p.price}</span>
                <span className={p.highlight ? "opacity-80" : "text-muted-foreground"}>{p.period}</span>
              </div>
              <ul className="space-y-3 mb-8">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm">
                    <Check
                      className={`size-5 flex-shrink-0 ${p.highlight ? "" : "text-primary"}`}
                      strokeWidth={3}
                    />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <a
                href="#cta"
                className={`block text-center py-3.5 rounded-xl font-semibold transition-all hover:scale-[1.02] ${
                  p.highlight
                    ? "bg-foreground text-background"
                    : "bg-gradient-primary text-primary-foreground"
                }`}
              >
                {p.cta}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
