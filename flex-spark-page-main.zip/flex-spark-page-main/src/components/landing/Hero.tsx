import { Apple, Play, Star } from "lucide-react";
import appMockup from "@/assets/app-mockup.png";

export function Hero() {
  return (
    <section className="relative bg-hero overflow-hidden pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <div className="absolute top-1/4 -left-20 size-72 rounded-full bg-primary/20 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 size-96 rounded-full bg-secondary/20 blur-[140px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass text-xs font-semibold uppercase tracking-wider mb-6">
              <span className="size-2 rounded-full bg-primary animate-pulse-glow" />
              #1 Fitness App of 2026
            </div>

            <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-black leading-[0.95] mb-6">
              Train<br />
              <span className="text-gradient-primary">Harder.</span><br />
              Live <span className="italic font-light">Stronger.</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground max-w-xl mb-8 leading-relaxed">
              AI-powered workouts, smart calorie tracking, and real-time coaching —
              all in one app that adapts to your goals, your body, your pace.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <a
                href="#cta"
                className="group inline-flex items-center gap-3 bg-foreground text-background px-6 py-4 rounded-2xl font-semibold hover:scale-105 transition-transform shadow-card"
              >
                <Apple className="size-6" />
                <div className="text-left leading-tight">
                  <div className="text-[10px] uppercase opacity-70">Download on the</div>
                  <div className="text-base">App Store</div>
                </div>
              </a>
              <a
                href="#cta"
                className="group inline-flex items-center gap-3 bg-gradient-primary text-primary-foreground px-6 py-4 rounded-2xl font-semibold hover:scale-105 transition-transform shadow-glow"
              >
                <Play className="size-6 fill-current" />
                <div className="text-left leading-tight">
                  <div className="text-[10px] uppercase opacity-80">Get it on</div>
                  <div className="text-base">Google Play</div>
                </div>
              </a>
            </div>

            <div className="flex items-center gap-6">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="size-10 rounded-full border-2 border-background bg-gradient-to-br from-primary to-secondary"
                  />
                ))}
              </div>
              <div>
                <div className="flex items-center gap-1 text-primary">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="size-4 fill-current" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground">
                  <span className="text-foreground font-bold">2M+</span> athletes training daily
                </p>
              </div>
            </div>
          </div>

          <div className="relative animate-fade-in flex justify-center lg:justify-end">
            <div className="absolute inset-0 bg-gradient-primary blur-3xl opacity-30 rounded-full" />
            <img
              src={appMockup}
              alt="Pulse fitness app on smartphone showing workout dashboard"
              width={600}
              height={600}
              className="relative z-10 w-full max-w-md animate-float drop-shadow-2xl"
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6 md:gap-12 mt-20 pt-12 border-t border-border/50">
          {[
            { n: "2M+", l: "Active Users" },
            { n: "500+", l: "Workout Plans" },
            { n: "4.9★", l: "App Rating" },
          ].map((s) => (
            <div key={s.l} className="text-center md:text-left">
              <div className="text-4xl md:text-5xl font-display font-black text-gradient-primary">{s.n}</div>
              <div className="text-sm text-muted-foreground uppercase tracking-wider mt-1">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
