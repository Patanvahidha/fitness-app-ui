import { Check } from "lucide-react";
import athlete from "@/assets/hero-athlete.jpg";

const benefits = [
  "Personalized plans that evolve with you",
  "Science-backed programs from elite coaches",
  "Works offline — train anywhere, anytime",
  "Syncs with Apple Health, Google Fit & Strava",
];

export function About() {
  return (
    <section id="about" className="py-24 md:py-32 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="absolute -inset-4 bg-gradient-primary blur-3xl opacity-20 rounded-3xl" />
            <div className="relative rounded-3xl overflow-hidden aspect-[4/5] shadow-card border border-border">
              <img
                src={athlete}
                alt="Athletic man training with Pulse fitness app"
                width={800}
                height={1000}
                loading="lazy"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 glass rounded-2xl p-5">
                <div className="text-xs uppercase tracking-widest text-primary mb-1">Today's Session</div>
                <div className="font-display font-bold text-xl">Upper Body Power · 48 min</div>
                <div className="mt-3 h-1.5 bg-border rounded-full overflow-hidden">
                  <div className="h-full w-[72%] bg-gradient-primary rounded-full" />
                </div>
              </div>
            </div>
          </div>

          <div>
            <div className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-widest mb-4">
              Why Pulse
            </div>
            <h2 className="text-4xl md:text-6xl font-display font-black mb-6 leading-[1.05]">
              Your body. Your goals.<br />
              <span className="text-gradient-primary">Your plan.</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              We believe fitness shouldn't feel like guesswork. Pulse combines cutting-edge AI
              with decades of coaching expertise to build a program that's genuinely yours —
              one that gets smarter every single workout.
            </p>

            <ul className="space-y-4 mb-10">
              {benefits.map((b) => (
                <li key={b} className="flex items-start gap-3">
                  <div className="size-6 rounded-full bg-gradient-primary flex items-center justify-center mt-0.5 flex-shrink-0">
                    <Check className="size-4 text-primary-foreground" strokeWidth={3} />
                  </div>
                  <span className="text-foreground">{b}</span>
                </li>
              ))}
            </ul>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-surface/60 border border-border rounded-2xl p-5">
                <div className="text-3xl font-display font-black text-gradient-primary">92%</div>
                <div className="text-sm text-muted-foreground mt-1">Hit their goals in 12 weeks</div>
              </div>
              <div className="bg-surface/60 border border-border rounded-2xl p-5">
                <div className="text-3xl font-display font-black text-gradient-primary">-18lb</div>
                <div className="text-sm text-muted-foreground mt-1">Avg fat loss per user</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
