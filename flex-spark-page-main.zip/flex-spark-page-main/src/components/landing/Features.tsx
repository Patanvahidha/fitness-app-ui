import { Dumbbell, Flame, LineChart, UserCog, Timer, HeartPulse } from "lucide-react";

const features = [
  {
    icon: Dumbbell,
    title: "Smart Workout Plans",
    desc: "500+ guided routines that adapt in real time based on your performance and recovery.",
  },
  {
    icon: Flame,
    title: "Calorie & Macro Tracking",
    desc: "Snap a photo of your meal — our AI instantly logs calories, protein, carbs, and fats.",
  },
  {
    icon: LineChart,
    title: "Progress Analytics",
    desc: "Beautiful dashboards tracking strength, body composition, sleep, and cardio trends.",
  },
  {
    icon: UserCog,
    title: "Personalized Coaching",
    desc: "Your AI coach adjusts intensity, volume, and rest weekly to match your goals.",
  },
  {
    icon: Timer,
    title: "HIIT & Interval Timer",
    desc: "Built-in voice-guided timers for HIIT, Tabata, EMOM, and custom circuits.",
  },
  {
    icon: HeartPulse,
    title: "Heart Rate Sync",
    desc: "Pair with Apple Watch, Garmin, or Whoop to train in the perfect zone every time.",
  },
];

export function Features() {
  return (
    <section id="features" className="py-24 md:py-32 relative">
      <div className="container mx-auto px-6">
        <div className="max-w-2xl mb-16">
          <div className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-widest mb-4">
            Features
          </div>
          <h2 className="text-4xl md:text-6xl font-display font-black mb-5">
            Everything you need.<br />
            <span className="text-gradient-primary">Nothing you don't.</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Built by coaches, athletes, and engineers — Pulse packs pro-level training tools
            into one effortlessly simple app.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="group relative bg-surface/60 border border-border rounded-3xl p-8 hover:border-primary/60 hover:bg-surface transition-all duration-300 hover:-translate-y-2"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="size-14 rounded-2xl bg-gradient-primary flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-6 transition-transform shadow-glow">
                <f.icon className="size-7 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-display font-bold mb-3">{f.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{f.desc}</p>
              <div className="absolute inset-0 rounded-3xl bg-gradient-primary opacity-0 group-hover:opacity-[0.03] transition-opacity pointer-events-none" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
