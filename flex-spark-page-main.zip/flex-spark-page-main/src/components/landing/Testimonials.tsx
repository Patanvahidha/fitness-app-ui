import { Star, Quote } from "lucide-react";
import t1 from "@/assets/testimonial-1.jpg";
import t2 from "@/assets/testimonial-2.jpg";
import t3 from "@/assets/testimonial-3.jpg";

const reviews = [
  {
    img: t1,
    name: "Sarah Mitchell",
    role: "Marathon Runner",
    text: "Pulse completely transformed how I train. The AI adapts my plan based on how I'm actually feeling — I shaved 12 minutes off my PR in 4 months.",
  },
  {
    img: t2,
    name: "Marcus Chen",
    role: "Powerlifter",
    text: "The best training app I've used, and I've tried them all. The analytics are pro-grade and the coaching cues actually fix form issues.",
  },
  {
    img: t3,
    name: "Elena Rossi",
    role: "Busy Mom of 3",
    text: "Lost 22 pounds without feeling like I'm dieting. The workouts fit in 20 minutes and the meal scanner makes tracking effortless.",
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="py-24 md:py-32 relative">
      <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
      <div className="container mx-auto px-6 relative">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-widest mb-4">
            Testimonials
          </div>
          <h2 className="text-4xl md:text-6xl font-display font-black mb-5">
            Loved by <span className="text-gradient-primary">real athletes</span>.
          </h2>
          <p className="text-lg text-muted-foreground">
            Over 2 million people are reshaping their fitness with Pulse. Here's what they say.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {reviews.map((r) => (
            <figure
              key={r.name}
              className="relative bg-surface/60 border border-border rounded-3xl p-8 hover:border-primary/50 transition-all hover:-translate-y-2 duration-300"
            >
              <Quote className="absolute top-6 right-6 size-10 text-primary/20" />
              <div className="flex items-center gap-1 text-primary mb-5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="size-4 fill-current" />
                ))}
              </div>
              <blockquote className="text-foreground leading-relaxed mb-6">"{r.text}"</blockquote>
              <figcaption className="flex items-center gap-3 pt-5 border-t border-border">
                <img
                  src={r.img}
                  alt={r.name}
                  width={48}
                  height={48}
                  loading="lazy"
                  className="size-12 rounded-full object-cover border-2 border-primary/30"
                />
                <div>
                  <div className="font-bold">{r.name}</div>
                  <div className="text-sm text-muted-foreground">{r.role}</div>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
