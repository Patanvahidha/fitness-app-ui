import { Apple, Play } from "lucide-react";

export function CTA() {
  return (
    <section id="cta" className="py-24 md:py-32 relative">
      <div className="container mx-auto px-6">
        <div className="relative rounded-[2.5rem] bg-gradient-primary p-12 md:p-20 overflow-hidden shadow-glow">
          <div className="absolute top-0 right-0 size-96 rounded-full bg-secondary/40 blur-3xl" />
          <div className="absolute bottom-0 left-0 size-96 rounded-full bg-foreground/10 blur-3xl" />

          <div className="relative text-center max-w-3xl mx-auto text-primary-foreground">
            <h2 className="text-5xl md:text-7xl font-display font-black mb-6 leading-[1.05]">
              Your strongest self<br />starts today.
            </h2>
            <p className="text-lg md:text-xl opacity-90 mb-10 max-w-xl mx-auto">
              Join 2 million athletes already training smarter. Download Pulse free — no credit card required.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="#"
                className="group inline-flex items-center gap-3 bg-foreground text-background px-7 py-4 rounded-2xl font-semibold hover:scale-105 transition-transform"
              >
                <Apple className="size-6" />
                <div className="text-left leading-tight">
                  <div className="text-[10px] uppercase opacity-70">Download on the</div>
                  <div className="text-base">App Store</div>
                </div>
              </a>
              <a
                href="#"
                className="group inline-flex items-center gap-3 bg-background text-foreground px-7 py-4 rounded-2xl font-semibold hover:scale-105 transition-transform"
              >
                <Play className="size-6 fill-current" />
                <div className="text-left leading-tight">
                  <div className="text-[10px] uppercase opacity-70">Get it on</div>
                  <div className="text-base">Google Play</div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
