import { Dumbbell, Instagram, Twitter, Youtube, Facebook } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border pt-20 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-5 gap-10 mb-14">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 font-display font-bold text-xl mb-4">
              <div className="size-9 rounded-xl bg-gradient-primary flex items-center justify-center text-primary-foreground">
                <Dumbbell className="size-5" />
              </div>
              <span>PULSE<span className="text-primary">.</span></span>
            </div>
            <p className="text-muted-foreground max-w-sm mb-6">
              The intelligent fitness app built for athletes who want to train smarter, not just harder.
            </p>
            <div className="flex gap-3">
              {[Instagram, Twitter, Youtube, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="size-10 rounded-full bg-surface border border-border flex items-center justify-center hover:bg-gradient-primary hover:text-primary-foreground hover:border-transparent transition-all hover:-translate-y-1"
                  aria-label="Social link"
                >
                  <Icon className="size-4" />
                </a>
              ))}
            </div>
          </div>

          {[
            { t: "Product", l: ["Features", "Pricing", "Workouts", "Nutrition", "Coaches"] },
            { t: "Company", l: ["About", "Careers", "Press", "Blog", "Contact"] },
            { t: "Support", l: ["Help Center", "Community", "Privacy", "Terms", "Status"] },
          ].map((col) => (
            <div key={col.t}>
              <h4 className="font-display font-bold mb-4">{col.t}</h4>
              <ul className="space-y-3">
                {col.l.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © 2026 Pulse Fitness Inc. · hello@pulse.app · Crafted for those who never settle.
          </p>
          <p className="text-sm text-muted-foreground">
            Made with <span className="text-primary">♥</span> for athletes everywhere.
          </p>
        </div>
      </div>
    </footer>
  );
}
