import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/landing/Navbar";
import { Hero } from "@/components/landing/Hero";
import { Features } from "@/components/landing/Features";
import { About } from "@/components/landing/About";
import { Testimonials } from "@/components/landing/Testimonials";
import { Pricing } from "@/components/landing/Pricing";
import { CTA } from "@/components/landing/CTA";
import { Footer } from "@/components/landing/Footer";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Pulse — Train Harder. Live Stronger. | AI Fitness App" },
      {
        name: "description",
        content:
          "Pulse is the AI-powered fitness app with smart workouts, calorie tracking, progress analytics, and personalized coaching. Join 2M+ athletes.",
      },
      { property: "og:title", content: "Pulse — The AI Fitness App for Real Athletes" },
      {
        property: "og:description",
        content: "Smart workouts, calorie tracking, and personalized coaching — all in one app.",
      },
    ],
  }),
});

function Index() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <Navbar />
      <Hero />
      <Features />
      <About />
      <Testimonials />
      <Pricing />
      <CTA />
      <Footer />
    </main>
  );
}
